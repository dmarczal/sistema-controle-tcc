function setEvents(ctrlAngular){

}
;
